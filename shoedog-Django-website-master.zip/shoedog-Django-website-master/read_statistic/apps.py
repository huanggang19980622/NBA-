from django.apps import AppConfig


class ReadStatisticConfig(AppConfig):
    name = 'read_statistic'
