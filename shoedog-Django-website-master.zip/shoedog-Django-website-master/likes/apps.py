from django.apps import AppConfig


class LikesConfig(AppConfig):
    name = 'likes'
